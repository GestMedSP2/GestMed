# GestMed
Sistema de gerenciamento de temperatura e umidade de locais que armazenam medicamentos, vacinas e insumos
