// geral
Chart.defaults.font.family = 'Poppins';

const horario = [
    '12:00',
    '12:15',
    '12:30',
    '12:45',
    '13:00',
    '13:15',
]

const semana = [
    'Dom',
    'Seg',
    'Ter',
    'Qua',
    'Qui',
    'Sex',
    'Sab'
]

// // Gráfico média

//     const temperaturaMedia = [22, 24, 27, 23, 20, 18, 22];
//     const umidadeMedia = [90, 89, 93, 87, 88 , 70, 75];

//     const barChart = document.getElementById('myBarChart');

//     new Chart(barChart, {
//         data: {
//             datasets: [
//                 {
//                     type: 'bar',
//                     label: 'Temperatura média',
//                     data: temperaturaMedia,
//                     backgroundColor: '#50C37E',
//                     borderRadius: 10,
//                 },
//                 {
//                     type: 'bar',
//                     label: 'Umidade média',
//                     data: umidadeMedia,
//                     backgroundColor: '#708BFF',
//                     borderRadius: 10,
//                 }
//             ],
//             labels: semana
//         },
//     });
